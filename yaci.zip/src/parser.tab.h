/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_SRC_PARSER_TAB_H_INCLUDED
# define YY_YY_SRC_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    NUM = 258,                     /* NUM  */
    DEC = 259,                     /* DEC  */
    STR = 260,                     /* STR  */
    FUN = 261,                     /* FUN  */
    LIST = 262,                    /* LIST  */
    PATH = 263,                    /* PATH  */
    VAR = 264,                     /* VAR  */
    ERROR = 265,                   /* ERROR  */
    ASSERT = 266,                  /* ASSERT  */
    AS = 267,                      /* AS  */
    TYPE = 268,                    /* TYPE  */
    CONST = 269,                   /* CONST  */
    WORKSPACE = 270,               /* WORKSPACE  */
    CLEAR = 271,                   /* CLEAR  */
    QUIT = 272,                    /* QUIT  */
    LOAD = 273,                    /* LOAD  */
    VERBOSE = 274,                 /* VERBOSE  */
    T_ECHO = 275,                  /* T_ECHO  */
    TRUE = 276,                    /* TRUE  */
    FALSE = 277,                   /* FALSE  */
    HELP = 278,                    /* HELP  */
    OPEN = 279,                    /* OPEN  */
    POLL = 280,                    /* POLL  */
    ARROW = 281,                   /* ARROW  */
    DEL = 282,                     /* DEL  */
    ALL = 283,                     /* ALL  */
    NEG = 284                      /* NEG  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 32 "src/parser.y"

    struct TS_Entry *tptr;
    struct Lit val;
    int type;

#line 99 "src/parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_SRC_PARSER_TAB_H_INCLUDED  */
